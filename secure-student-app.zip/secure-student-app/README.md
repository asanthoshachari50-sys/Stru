# Secure Student Management System

A learning-focused Java Full-Stack application demonstrating layered security.

## Stack
- Backend: Java 17+, Spring Boot 3.4.x, Spring Security 6, JPA/Hibernate
- Database: MySQL 8+
- Frontend: plain HTML/CSS/JavaScript (easy to run and understand)
- Auth: JWT + BCrypt
- Validation: Jakarta Bean Validation
- Rate limiting: simple in-memory login limiter
- CORS: allow-list
- Security headers: Spring Security
- Secrets: environment variables
- SQL injection protection: JPA repository / parameterized persistence

## Security model
This app uses stateless Bearer JWT authentication, so CSRF is disabled deliberately for API requests that authenticate only with Authorization headers. If you change the app to cookie-based authentication, re-enable and configure CSRF protection.

## Run
1. Create a MySQL database:
   CREATE DATABASE secure_student_app;
2. Set environment variables:
   DB_USERNAME=root
   DB_PASSWORD=your_password
   JWT_SECRET=replace_with_a_long_random_secret_at_least_32_bytes
3. From backend:
   ./mvnw spring-boot:run
   (Windows: mvnw.cmd spring-boot:run)
4. Open frontend/index.html in a browser, or serve the frontend folder with a local static server.

Default API: http://localhost:8080

## Demo registration
Register a user through the UI. To create an ADMIN for testing, insert/update a user's role in MySQL after registration:
UPDATE users SET role='ADMIN' WHERE email='your@email.com';

Do not use this shortcut in production; use a controlled admin provisioning workflow.

## Production checklist
- Put the API behind HTTPS/TLS.
- Use a strong randomly generated JWT secret stored outside source control.
- Use a dedicated least-privilege database account.
- Replace the in-memory rate limiter with a distributed limiter such as Redis at scale.
- Add email verification, password reset, refresh-token rotation, account lockout, audit storage, backups, monitoring and secret rotation as needed.
- Keep dependencies patched and enable dependency scanning.
