package com.example.secureapp.service;

import com.example.secureapp.dto.AuthResponse;
import com.example.secureapp.dto.LoginRequest;
import com.example.secureapp.dto.RegisterRequest;
import com.example.secureapp.dto.UserResponse;
import com.example.secureapp.model.User;
import com.example.secureapp.repository.UserRepository;
import com.example.secureapp.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository users, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public UserResponse register(RegisterRequest request) {
        String email = request.email().trim().toLowerCase();

        if (users.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException("Email already registered.");
        }

        User user = new User();
        user.setName(request.name().trim());
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(request.password()));

        User saved = users.save(user);
        return toResponse(saved);
    }

    public AuthResponse login(LoginRequest request) {
        User user = users.findByEmailIgnoreCase(request.email().trim().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials."));

        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid credentials.");
        }

        String token = jwtService.generate(user.getEmail(), user.getRole().name());
        return new AuthResponse(token, toResponse(user));
    }

    public UserResponse me(String email) {
        return users.findByEmailIgnoreCase(email)
                .map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("User not found."));
    }

    private UserResponse toResponse(User user) {
        return new UserResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name());
    }
}
