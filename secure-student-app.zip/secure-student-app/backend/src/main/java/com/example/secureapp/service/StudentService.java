package com.example.secureapp.service;

import com.example.secureapp.dto.UserResponse;
import com.example.secureapp.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    private final UserRepository users;

    public StudentService(UserRepository users) {
        this.users = users;
    }

    public List<UserResponse> allUsers() {
        return users.findAll().stream()
                .map(u -> new UserResponse(u.getId(), u.getName(), u.getEmail(), u.getRole().name()))
                .toList();
    }

    public void deleteUser(Long id) {
        if (!users.existsById(id)) {
            throw new IllegalArgumentException("User not found.");
        }
        users.deleteById(id);
    }
}
